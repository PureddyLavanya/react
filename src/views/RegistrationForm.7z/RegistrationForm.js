import React, { Fragment, useState } from "react";
import './styles.css';
import {
  Button,
  Modal,
  Col,
  Form,
  FormControl,
  FormGroup,
  FormLabel,
  FormCheck,
  FormSelect,
  Row,
} from "react-bootstrap";

const RegistrationForm = ({ show, handleClose }) => {
  // form validation
  const [validated, setValidated] = useState(false);

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    setValidated(true);
  };

  return (
    <Modal show={show} onHide={handleClose} size="lg">
      <Modal.Header closeButton>
        <Modal.Title className="text-center">Patient Registration Form</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Fragment>
          <div className="iq-card">
            <div className="iq-card-body">
              <Form
                className="needs-validation w-100"
                noValidate
                validated={validated}
                onSubmit={handleSubmit}
              >
                <Row className="mb-3">
                  <Col md="4">
                    <FormLabel className="mb-0" htmlFor="title">
                      Title
                    </FormLabel>
                    <FormSelect
                      id="title"
                      aria-label="Title"
                      required
                    >
                      <option value="">Select Title</option>
                      <option value="Mr">Mr</option>
                      <option value="Mrs">Mrs</option>
                      <option value="Miss">Miss</option>
                      <option value="Ms">Ms</option>
                      <option value="Dr">Dr</option>

                    </FormSelect>
                    <div className="invalid-feedback">Please select a title.</div>
                  </Col>
                  <Col md="4">
                    <FormLabel className="mb-0" htmlFor="validationCustom01">
                      First name
                    </FormLabel>
                    <FormControl
                      type="text"
                      className="form-control"
                      id="validationCustom01"
                      required
                    />
                    <div className="valid-feedback">Looks good!</div>
                  </Col>
                  <Col md="4">
                    <FormLabel className="mb-0" htmlFor="validationCustom02">
                      Last name
                    </FormLabel>
                    <FormControl
                      type="text"
                      className="form-control"
                      id="validationCustom02"
                      required
                    />
                    <div className="valid-feedback">Looks good!</div>
                  </Col>
                </Row>
                <Row className="mb-3">
                  <Col md="4">
                    <FormLabel className="mb-0" htmlFor="gender">
                      Gender
                    </FormLabel>
                    <FormSelect
                      id="gender"
                      aria-label="Gender"
                      required
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </FormSelect>
                    <div className="invalid-feedback">Please select a gender.</div>
                  </Col>
                  <Col md="4">
                    <FormLabel className="mb-0" htmlFor="mobileNo">
                      Mobile No
                    </FormLabel>
                    <FormControl
                      type="text"
                      className="form-control"
                      id="mobileNo"
                      required
                    />
                    <div className="invalid-feedback">Please provide a valid mobile number.</div>
                  </Col>
                  <Col md="4">
                    <FormLabel className="mb-0" htmlFor="dob">
                      Date of Birth
                    </FormLabel>
                    <FormControl
                      type="date"
                      className="form-control"
                      id="dob"
                      required
                    />
                    <div className="invalid-feedback">Please provide a valid date.</div>
                  </Col>
                </Row>
                <FormGroup className="form-group mb-3">
                  <FormCheck>
                    <FormCheck.Input
                      className="form-check-input"
                      type="checkbox"
                      value=""
                      id="invalidCheck"
                      required
                    />
                    <FormCheck.Label
                      className="form-check-label"
                      htmlFor="invalidCheck"
                    >
                      Agree to terms and conditions
                    </FormCheck.Label>
                    <FormControl.Feedback className="invalid-feedback">
                      You must agree before submitting.
                    </FormControl.Feedback>
                  </FormCheck>
                </FormGroup>
                <Button
                  variant="primary"
                  className="btn btn-primary"
                  type="submit"
                >
                  Submit form
                </Button>
              </Form>
            </div>
          </div>
        </Fragment>
      </Modal.Body>
    </Modal>
  );
};

export default RegistrationForm;
