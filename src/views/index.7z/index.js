import React, { Fragment,useState ,useEffect } from "react";
import { Col, Container, Dropdown, Row, Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import RegistrationForm from './RegistrationForm';

//apexcharts
import Chart from "react-apexcharts";

//flatpickr
import Flatpickr from "react-flatpickr";

// Img
import img from "../assets/images/user/11.png";
import user1 from "../assets/images/user/01.jpg";
import user2 from "../assets/images/user/02.jpg";
import user3 from "../assets/images/user/03.jpg";
import user4 from "../assets/images/user/04.jpg";
import user5 from "../assets/images/user/05.jpg";
import user6 from "../assets/images/user/06.jpg";
import user7 from "../assets/images/user/07.jpg";
import user8 from "../assets/images/user/08.jpg";
import user9 from "../assets/images/user/09.jpg";
import user10 from "../assets/images/user/10.jpg";

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
// eslint-disable-next-line camelcase
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_animated);

const Index = () => {
const [showForm, setShowForm] = useState(false);

const handleIconClick = () => setShowForm(true);
const handleCloseForm = () => setShowForm(false);
const bgImg = require("../assets/images/page-img//38.jpg");

  return (
    <Fragment>
     <Col lg="12">
            <Row>
              <Col md="6" lg="3">
                <div className="iq-card">
                  <div className="iq-card-body iq-bg-primary rounded-4">
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="rounded-circle iq-card-icon bg-primary">
                        <i className="ri-user-fill"></i>
                      </div>
                      <div className="text-end">
                        <h2 className="mb-0">
                          <span className="counter">600</span>
                        </h2>
                        <h5 className="">Patients </h5>
                      </div>
                    </div>
                  </div>
                </div>
              </Col>
              <Col md="6" lg="3">
                <div className="iq-card">
                  <div className="iq-card-body iq-bg-warning rounded-4">
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="rounded-circle iq-card-icon bg-warning">
                        <i className="ri-women-fill"></i>
                      </div>
                      <div className="text-end">
                        <h2 className="mb-0">
                          <span className="counter">450</span>
                        </h2>
                        <h5 className="">Out patients</h5>
                      </div>
                    </div>
                  </div>
                </div>
              </Col>
              <Col md="6" lg="3">
                <div className="iq-card">
                  <div className="iq-card-body iq-bg-danger rounded-4">
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="rounded-circle iq-card-icon bg-danger">
                        <i className="ri-group-fill"></i>
                      </div>
                      <div className="text-end">
                        <h2 className="mb-0">
                          <span className="counter">3500</span>
                        </h2>
                        <h5 className="">In Patients</h5>
                      </div>
                    </div>
                  </div>
                </div>
              </Col>
              <Col md="6" lg="3">
                <div className="iq-card">
                  <div className="iq-card-body iq-bg-info rounded-4">
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="rounded-circle iq-card-icon bg-info">
                        <i className="ri-hospital-line"></i>
                      </div>
                      <div className="text-end">
                        <h2 className="mb-0">
                          <span className="counter">500</span>
                        </h2>
                        <h5 className="">Today Patients </h5>
                      </div>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </Col>
          <Col lg="12">
            <Row>
             <Col md="6" lg="3">
                                 <div className="iq-icons-list" to="#" onClick={handleIconClick} >
                                    <div data-icon="p" className="icon"></div>
                                    <span>Patient Registration Form</span>
                                 </div>
                              </Col>

            </Row>
          </Col>
         <RegistrationForm show={showForm} handleClose={handleCloseForm} />
    </Fragment>
  );
};

export default Index;
